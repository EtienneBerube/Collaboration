Etienne Berube: 40052212
Nathan Gagnon: 40058053

Hi,

For assignment 5, my teammate and I did a GUI in order to learn QT.
In the following folders you will find the command line version and the Qt version.
For the QT version, just double-click on the .exe to run it (the dlls' are included in the folder). The source code is in the src_code folder (just in case).
The command line version is the original version. The code from the QT comes from the main file.

For the command line, the arguments go as follows: -<sort argument> <input path (COMPLETE)> <output path (complete)>
Note: There must be a '-' in front of the sort argument. ex: -id, -name, etc.

If something happens or for any question, you can email us:

tiennebrb@gmail.com
nathan.gagnon10@hotmail.com


Thanks,

Etienne and Nathon